const express = require('express');
const app = express();
const pool = require('./pg_db');
const sql = require('sql');
const cors = require('cors');
const PORT = 9000;

app.use(express.json());

app.use(cors());

app.use(function(req, res, next){
	res.header("Access-Control-Allow-Origin","*");
	res.header("Access-Control-Allow-Headers","Origin, X-Requested-With, Content-Type, Accept");
	next();
});

var comp_name = sql.define({
  name: 'comp_lib_name',
  columns: [
    'comp_name_id',
    'comp_name',
    'comp_desc',
    'created_by',
    'is_deleted'
  ]
});

var comp_level = sql.define({
  name: 'comp_lib_level',
  columns: [
    'comp_level_id',
    'comp_level_name',
    'comp_level_desc',
    'created_by',
    'comp_name_id',
    'is_deleted'
  ]
});

app.get('/',async(req, res)=>{

	try{
		res.json("Welcome to Competence Library");
	}
	catch(err){
		console.error(err.message);
	}
});


//get all
app.get('/compid',async(req, res)=>{

	try{

		const allCompIds = await pool.query("select n.comp_name_id, n.comp_name, n.comp_desc, n.created_by, l.comp_level_id, l.comp_level_name, l.comp_level_desc from comp_lib_name n, comp_lib_level l where n.comp_name_id = l.comp_name_id and n.is_deleted = false");

		res.json(allCompIds.rows);
	}
	catch(err){
		console.error(err.message);
	}
});

//get for specific ID
app.get('/compid/:id',async(req, res)=>{
	var {id} = req.params;
	var compID = req.params.id;
	try{
		var CompId = await pool.query("SELECT * FROM comp_lib_name WHERE comp_name_id = " + "'" + compID +"'");
		var CompLvl = await pool.query("SELECT * FROM comp_lib_level WHERE comp_name_id = " + "'" + compID +"'");

		res.json({status: true,
			  data: {
				 CompId,
				 CompLvl
				}
			});

	}
	catch(err){
		console.error(err.message);
	}
});

//update record
app.put('/compid/:id',async(req, res)=>{
	const {id} = req.params;
	const {comp_data} = req.body;
	try{
		var CompId = await pool.query('UPDATE comp_lib_name SET comp_name = $1, comp_desc = $2 WHERE comp_name_id = $3',[req.body.comp_name, req.body.comp_desc, id]);
		var lvlArr = req.body.level;
		for (i = 0; i < lvlArr.length; i++) {
				CompId = await pool.query('UPDATE comp_lib_level SET comp_level_desc = $2 WHERE comp_level_name = $1 and comp_name_id = $3',[lvlArr[i].name, lvlArr[i].description, id]);
		}
		res.json("Record successfully updated");
	}
	catch(err){
		console.error(err.message);
	}
});

//Delete record
app.put('/deleteid/:id',async(req, res)=>{
	const {id} = req.params;

	try{
		const CompId = await pool.query('UPDATE comp_lib_name SET is_deleted = TRUE WHERE comp_name_id = $1',[id]);
		var lvlArr = req.body.level;
		for (i = 0; i < lvlArr.length; i++) {
				CompId = await pool.query('UPDATE comp_lib_level SET is_deleted = true WHERE comp_name_id = $1',[id]);
		}
		res.json("Record successfully deleted");
	}
	catch(err){
		console.error(err.message);
	}
});

app.post('/comp_lib', async(req, res)=>{
	try {
		var arrCompLib = [];
		var objCompLib = {};
		var arrCompLvl = [];
		var objCompLvl = {};
		var complibunivID = await pool.query("SELECT uuid_generate_v1()");
		var complibunivIDval = complibunivID.rows[0].uuid_generate_v1;
		objCompLib.comp_name_id = complibunivIDval;
		objCompLib.comp_name = req.body.comp_name;
		objCompLib.comp_desc = req.body.comp_desc;
		objCompLib.created_by = "";
		objCompLib.is_deleted = false;
		arrCompLib.push(objCompLib);
		var lvlArr = req.body.level;
		for (i = 0; i < lvlArr.length; i++) {
			var univID = await pool.query("SELECT uuid_generate_v1()");
			var univIDval = univID.rows[0].uuid_generate_v1;
			objCompLvl.comp_level_id = univIDval;
			objCompLvl.comp_level_name = lvlArr[i].name;
			objCompLvl.comp_level_desc = lvlArr[i].description;
			objCompLvl.created_by = "";
			objCompLvl.comp_name_id = complibunivIDval;
			objCompLvl.is_deleted = false;
			arrCompLvl.push(objCompLvl);
			objCompLvl = {};
		}

		var newCompLibQry = comp_name.insert(arrCompLib).returning(comp_name.comp_name_id).toQuery();
		var newCompLvlQry = comp_level.insert(arrCompLvl).returning(comp_level.comp_level_id).toQuery();
		var {rowsName} = await pool.query(newCompLibQry);
		var {rowsLevel} = await pool.query(newCompLvlQry);
 
	res.json({status: true,
		  data: {
			 rowsName,
			 rowsLevel
			}
		});
	}
	catch (err){
		console.error(err.message);
	}
});


app.listen(PORT, ()=>{
	console.log("Server listening at Port " + PORT);
});