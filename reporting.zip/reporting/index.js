express = require('express');
sql = require('sql');
cors = require('cors');
const pool = require('./pg_db');

const PORT = 9000;

app = express();


app.use(cors());

app.use(function(req, res, next){
	res.header("Access-Control-Allow-Origin","*");
	res.header("Access-Control-Allow-Headers","Origin, X-Requested-With, Content-Type, Accept");
	next();
});

//get all organizations
app.get('/organization',async(req, res)=>{

	try{

		const allOrganization = await pool.query("SELECT public.organization.id, public.organization.name FROM public.organization WHERE public.organization.is_deleted = 'false' ORDER BY public.organization.name");

		res.json(allOrganization.rows);
	}
	catch(err){
		console.error(err.message);
	}
});

//get all employees for a tenantID - login user
app.get('/employee/:tenant_id/',async(req, res)=>{

	try{
		const tenant_id = req.params.tenant_id;
		const allEmp = await pool.query("SELECT public.user.id, public.user.display_name FROM public.user WHERE public.user.tenant_id = $1 AND public.user.is_deleted = 'false' AND public.user.is_hidden = 'false' ORDER BY public.user.display_name",[tenant_id]);

		res.json(allEmp.rows);
	}
	catch(err){
		console.error(err.message);
	}
});

//get all employees for a tenantID - login user
/*app.get('/employees/:tenant_id/:user_id',async(req, res)=>{

	try{
		const tenant_id = req.params.tenant_id;

		var qry = "SELECT public.user.id, public.user.display_name FROM public.user WHERE public.user.tenant_id = $1 AND public.user.is_deleted = 'false' AND public.user.is_hidden = 'false' "
		var order_by =  " ORDER BY public.user.display_name";
		if (req.params.user_id === 'null')
		{
			console.log(qry);
		}
		else{
			qry = qry +" and public.user.id = $2" + order_by;
			console.log(qry);
		}

		const allEmp = await pool.query("SELECT public.user.id, public.user.display_name FROM public.user WHERE public.user.tenant_id = $1 AND public.user.is_deleted = 'false' AND public.user.is_hidden = 'false' ORDER BY public.user.display_name",[tenant_id]);

		res.json(allEmp.rows);
	}
	catch(err){
		console.error(err.message);
	}
});
*/

//get Department Name for the login user  for display label
app.get('/deptname/:user_id',async(req, res)=>{

	try{
		const user_id = req.params.user_id;
		const deptName = await pool.query("SELECT public.department.id, public.department.name FROM public.department WHERE public.department.id IN (SELECT public.user.department FROM public.user WHERE public.user.id = $1)",[user_id]);

		res.json(deptName.rows);
	}
	catch(err){
		console.error(err.message);
	}
});

//get roles of login user for display label
app.get('/roles/:user_id',async(req, res)=>{

	try{
		const user_id = req.params.user_id;
		const roles = await pool.query("SELECT public.roles.id, public.roles.name FROM public.roles WHERE public.roles.id IN (SELECT public.user.roles FROM public.user WHERE public.user.id = $1)",[user_id]);

		res.json(roles.rows);
	}
	catch(err){
		console.error(err.message);
	}
});

//get Line Manager name for the login user for display label
app.get('/linemanager/:user_id',async(req, res)=>{

	try{
		const user_id = req.params.user_id;
		const lineMgr = await pool.query("SELECT public.user.id, public.user.display_name FROM public.user WHERE public.user.id IN (SELECT public.user.line_manager FROM public.user WHERE public.user.id = $1)",[user_id]);

		res.json(lineMgr.rows);
	}
	catch(err){
		console.error(err.message);
	}
});

//checking the CEO flag of a login user for display label
app.get('/isceo/:user_id',async(req, res)=>{

	try{
		const user_id = req.params.user_id;
		const isCeo = await pool.query("SELECT public.user.is_ceo FROM public.user WHERE public.user.id = $1",[user_id]);

		res.json(isCeo.rows);
	}
	catch(err){
		console.error(err.message);
		}
});

//checking the manager flag of the login user for display label
app.get('/ismanager/:user_id',async(req, res)=>{

	try{
		const user_id = req.params.user_id;
		const isMgr = await pool.query("SELECT public.user.is_manager FROM public.user WHERE public.user.id = $1",[user_id]);

		res.json(isMgr.rows);
	}
	catch(err){
		console.error(err.message);
	}
});

//get all departments for a tenantID for drop down
app.get('/department/:tenant_id/:userid',async(req, res)=>{

	try{
		const tenant_id = req.params.tenant_id;
		const userid = req.params.userid;
		var qryStr = "SELECT public.department.id, public.department.name FROM public.department WHERE public.department.tenant_id = $1 AND public.department.is_deleted = 'false' ";
		var order_by = " ORDER BY public.department.name";
		paramArr = [];
		paramArr.push(tenant_id);

		const isCeo = await pool.query("SELECT public.user.is_ceo FROM public.user WHERE public.user.id = $1",[userid]);

		const isLinemanager = await pool.query("SELECT public.user.is_manager FROM public.user WHERE public.user.id = $1",[userid]);

		if (isCeo.rows[0].is_ceo === 'false' && isLinemanager.rows[0].is_manager === 'true')
		{
				qryStr = qryStr + " and public.department.id IN (SELECT public.user.department from public.user where public.user.id IN (SELECT public.user.id FROM public.user WHERE public.user.line_manager = $2) )";
				paramArr.push(userid);
		}

		if (isCeo.rows[0].is_ceo === 'false' && isLinemanager.rows[0].is_manager === 'false')
		{
				qryStr = qryStr + " and public.department.id IN (SELECT public.user.department from public.user where public.user.id = $2)";
				paramArr.push(userid);
		}

		qryStr = qryStr + order_by;

		const allDept = await pool.query(qryStr,paramArr);

		res.json(allDept.rows);
	}
	catch(err){
		console.error(err.message);
	}
});

//get all employee names for a line manager - employee drop down
app.get('/emplist/:user_id/:locationid/:deptid',async(req, res)=>{

	try{
		const userid = req.params.user_id;

		const deptid = req.params.deptid;

		const locationid = req.params.locationid;
		var paramArr = [];
		paramArr.push(userid);
		var qryStr = "SELECT public.user.id, public.user.display_name FROM public.user WHERE is_deleted = 'false' and is_hidden = 'false' and tenant_id IN (select tenant_id from public.user where public.user.id = $1)";
		var order_by = " order by display_name ";
		var deptqry = "";
		var locqry = "";
    var inString = "";
		var inArr = "";
		var arr = "";

		const isCeo = await pool.query("SELECT public.user.is_ceo FROM public.user WHERE public.user.id = $1",[userid]);
		const isLinemanager = await pool.query("SELECT public.user.is_manager FROM public.user WHERE public.user.id = $1",[userid]);
		console.log(isCeo.rows);
		console.log(isLinemanager.rows);

  	if (isCeo.rows[0].is_ceo === 'false' && isLinemanager.rows[0].is_manager === 'true')
		{
			if (locationid !== 'null' && deptid === 'null')
			{
				qryStr = qryStr + locqry;
			}

			if (locationid !== 'null')
			{
				locqry = " AND public.user.work_location = $" + String(paramArr.length + 1);
				paramArr.push(locationid);
			}

			if (deptid !== 'null') {
				 arr = deptid.slice(1, deptid.length);
				 arr = arr.slice(0,arr.length - 1);
				 console.log(arr);
				 console.log(arr.replace(/"/g,''));
				 arr = arr.replace(/"/g,'');
				 inArr = arr.split(',');
				 console.log(inArr);
			   inString = "(";
				 console.log(inArr);
				 for (i = paramArr.length; i < inArr.length + paramArr.length; i++) {

				 	 	 inString += "$" + (i+1);
				 	 	 if (i < inArr.length + paramArr.length - 1)
								inString += ",";
				 		 if (i === inArr.length + paramArr.length - 1)
								inString += ")";
					   var arr = deptid.slice(1, deptid.length);
					}

				 paramArr = paramArr.concat(inArr);
			}


			if (deptid !== 'null' && locationid === 'null')
			{
				deptqry = " AND public.user.department IN  ";
				qryStr = qryStr + deptqry + inString;
			}

			if (locationid !== 'null' && deptid !== 'null')
			{
				deptqry = " AND public.user.department IN ";
				qryStr = qryStr + deptqry + inString + " INTERSECT " + qryStr + locqry;
			}

		}

		if (isCeo.rows[0].is_ceo === 'false' && isLinemanager.rows[0].is_manager === 'false')
		{
			qryStr = "SELECT public.user.id, public.user.display_name FROM public.user WHERE public.user.id = $1 AND is_deleted = 'false' and is_hidden = 'false' "
		}

  		qryStr = qryStr + order_by;
			console.log(qryStr);
			console.log("input parameters");
			console.log(paramArr);
			const empList = await pool.query(qryStr, paramArr);

		res.json(empList.rows);

	}
	catch(err){
		console.error(err.message);
	}
});

//get location for tenantID for location drop down
app.get('/location/:tenant_id/:userid',async(req, res)=>{

			try{
				const tenant_id = req.params.tenant_id;
				const user_id = req.params.userid;

				var qryStr = "SELECT public.location.id, public.location.identification_name FROM public.location WHERE public.location.tenant_id = $1 AND public.location.is_deleted = 'false' "
				var order_by = " ORDER BY public.location.identification_name "
				paramArr = [];
				paramArr.push(tenant_id);

				const isCeo = await pool.query("SELECT public.user.is_ceo FROM public.user WHERE public.user.id = $1",[user_id]);

				const isLinemanager = await pool.query("SELECT public.user.is_manager FROM public.user WHERE public.user.id = $1",[user_id]);

				if (isCeo.rows[0].is_ceo === 'false' && isLinemanager.rows[0].is_manager === 'true')
				{
						qryStr = qryStr + " and public.location.id IN (SELECT public.user.work_location from public.user where public.user.id IN (SELECT public.user.id FROM public.user WHERE public.user.line_manager = $2) )";
						paramArr.push(user_id);
				}

				if (isCeo.rows[0].is_ceo === 'false' && isLinemanager.rows[0].is_manager === 'false')
				{
				  	qryStr = qryStr + " and public.location.id IN (SELECT public.user.work_location from public.user where public.user.id = $2) ";
						paramArr.push(user_id);
				}

				qryStr = qryStr + order_by;

				const allLoc = await pool.query(qryStr,paramArr);

				res.json(allLoc.rows);
			}
			catch(err){
				console.error(err.message);
			}
		});

		//get all performance cycles for tenantID for drop down
		app.get('/perfcycle/:tenant_id',async(req, res)=>{

			try{
				const tenant_id = req.params.tenant_id;
				var objPerf = {};
				var arrPerf = [];

				const allPerf = await pool.query("SELECT public.app_settings.id, public.app_settings.settings FROM public.app_settings WHERE public.app_settings.tenant_id = $1 ",[tenant_id]);
				const settings = JSON.parse(allPerf.rows[0].settings);
				const id = allPerf.rows[0].id;

				var cycles = settings.cycles;
				for( i = 0; i < cycles.length; i++){
					objPerf.performance_cycle = cycles[i].name;
					arrPerf.push(objPerf);
					objPerf = {};
				}
				const name = arrPerf
				res.json({id,name});
				arrPerf = [];
			}
			catch(err){
				console.error(err.message);
			}
		});

//get business unit for tenant id - temporarily disabled
/*app.get('/business_unit/:tenant_id',async(req, res)=>{

	try{
		const tenant_id = req.params.tenant_id;
		const allBusinessUnit = await pool.query("SELECT public.business_unit.id, public.business_unit.name FROM public.business_unit WHERE public.business_unit.tenant_id = $1 AND public.business_unit.is_deleted = 'false' ORDER BY public.business_unit.name",[tenant_id]);

		res.json(allBusinessUnit.rows);
	}
	catch(err){
		console.error(err.message);
	}
});
*/

//get all users for a tenantID to check where used
/*app.get('/user/:tenant_id',async(req, res)=>{

	try{
		const tenant_id = req.params.tenant_id;
		const allUser = await pool.query("SELECT public.user.id, public.user.display_name FROM public.user WHERE public.user.tenant_id = $1 AND public.user.is_deleted = 'false' AND public.user.is_hidden = 'false' ORDER BY public.user.display_name",[tenant_id]);

		res.json(allUser.rows);
	}
	catch(err){
		console.error(err.message);
	}
});
*/

//INDIVIDUAL DETAIL Report
app.get('/indivdtls/:tenantid/:locationid/:deptid/:userid/:startdate/:enddate',async(req, res)=>{

	try{
		const tenant_id = req.params.tenantid;

		const deptid = req.params.deptid;

		console.log(String(deptid));
		var arr = deptid.slice(1, deptid.length);

		arr = arr.slice(0,arr.length - 1);
		console.log(arr);
		console.log(arr.replace(/"/g,''));
		arr = arr.replace(/"/g,'');
		var inArr = arr.split(',');
		console.log(inArr);

		var paramArr = [];
		var order_by =  " ORDER BY u.display_name";
		var qryStr = 											" select u.work_location, u.business_unit, d.name department, u.employee_id EmpCode, u.display_name EmpName, u.designation, lm.employee_id linemanagerecode, " +
																			"  			 lm.display_name line_manager, (select sum( cast(ke.obj_progress as real))/count(distinct ke.objective_id) inv_perf from key_results ke where ke.user_id = k.user_id group by ke.user_id) Indiv_Perf, " +
																			" 			 o.description Obj_Desc, o.objective_type Objective_Type, o.category Category, ob.display_name Obj_Owner, " +
																			" 			 (select sum(cast (ky.obj_progress as real)) obj_progress from key_results ky where ky.objective_id = k.objective_id  group by ky.objective_id) Obj_Progress, " +
																			" 			 k.description KR_Desc, kr.display_name KR_Owner, o.progress KR_Progress " +
																			" from " +
																			" public.user u, " +
																			" public.key_results k, " +
																			" public.objectives o, " +
																			" public.department d, " +
																			" public.user lm, " +
																			" public.user ob, " +
																			" public.user kr " +
																			" where " +
																			" u.id = k.user_id and " +
																			" u.tenant_id = k.tenant_id and " +
																			" k.objective_id = o.id and " +
																			" u.department = d.id and " +
																			" lm.id = u.line_manager and " +
																			" ob.id = o.user_id and " +
																			" kr.id = k.user_id and " +
																			" u.tenant_id =  $1 ";
		paramArr.push(tenant_id);

		if (req.params.locationid !== 'null')
		{
				qryStr += " and u.work_location = $" + String(paramArr.length + 1);
				paramArr.push(req.params.locationid);
		};

		if (req.params.userid !== 'null')
		{
				qryStr += " and u.id = $" + String(paramArr.length + 1);
				paramArr.push(req.params.userid);
		};

		if (req.params.startdate !== 'null')
		{
				qryStr += " and cast(k.start_date as date) >= $" + String(paramArr.length + 1);
				paramArr.push(req.params.startdate);
		};

		if (req.params.enddate !== 'null')
		{
				qryStr += " and cast(k.end_date as date) <= $" + String(paramArr.length + 1);
				paramArr.push(req.params.enddate);
		};

		if (req.params.deptid !== 'null')
		{
			var inString = "("
			for (i = paramArr.length; i < inArr.length + paramArr.length; i++){
				inString += "$" + (i+1);
				if (i < inArr.length + paramArr.length - 1)
				inString += ",";
				if (i === inArr.length + paramArr.length - 1)
				inString += ")";
			}
			console.log(inString);
			paramArr = paramArr.concat(inArr);
			qryStr += " and u.department IN " + inString;
		};

		qryStr = qryStr + order_by;
		console.log(qryStr);
		console.log(String("G"));
		const indvDtls = await pool.query(qryStr,paramArr);

		res.json(indvDtls.rows);
	}
	catch(err){
		console.error(err.message);
	}
});

//INDIVIDUAL SUMMARY Report
app.get('/indivsummary/:tenant_id/:locationid/:deptid/:userid/:startdate/:enddate',async(req, res)=>{

	try{
		const tenant_id = req.params.tenant_id;

		const deptid = req.params.deptid;

		console.log(String(deptid));
		var arr = deptid.slice(1, deptid.length);

		arr = arr.slice(0,arr.length - 1);
		console.log(arr);
		console.log(arr.replace(/"/g,''));
		arr = arr.replace(/"/g,'');
		var inArr = arr.split(',');
		console.log(inArr);
		var paramArr = [];
		paramArr.push(tenant_id);
		console.log(paramArr);
		var order_by =  " ORDER BY u.display_name";
		var qryStr = " select u.work_location, u.business_unit, d.name department, u.employee_id, u.display_name EmpName, u.designation, lm.employee_id linemanagerecode, " +
 						     " 			  lm.display_name line_manager, (select sum( cast(ke.obj_progress as real))/count(distinct ke.objective_id) inv_perf from key_results ke where ke.user_id = k.user_id group by ke.user_id) Indiv_Perf " +
 						  	 " from " +
 						  	 " public.user u, " +
						  	 " public.key_results k, " +
						  	 " public.objectives o, " +
						  	 " public.department d, " +
						  	 " public.user lm " +
						  	 " where " +
						  	 " u.id = k.user_id and " +
						  	 " u.tenant_id = k.tenant_id and " +
						  	 " k.objective_id = o.id and " +
						  	 " u.department = d.id and " +
						  	 " lm.id = u.line_manager and " +
						  	 " u.tenant_id =  $1 ";

 		if (req.params.locationid !== 'null')
		{
			qryStr += " and u.work_location = $" + String(paramArr.length + 1);
			paramArr.push(req.params.locationid);
		};

	 if (req.params.userid !== 'null')
	 {
	  qryStr += " and u.id = $" + String(paramArr.length + 1);
		paramArr.push(req.params.userid);
	 };

	 if (req.params.startdate !== 'null')
	 {
	  qryStr += " and cast(k.start_date as date) >= $" + String(paramArr.length + 1);
	  paramArr.push(req.params.startdate);
	 };

	 if (req.params.enddate !== 'null')
  	{
			qryStr += " and cast(k.end_date as date) <= $" + String(paramArr.length + 1)
			paramArr.push(req.params.enddate);
		};

	if (req.params.deptid !== 'null')
	{
			var inString = "("
			for (i = paramArr.length; i < inArr.length + paramArr.length; i++){
					inString += "$" + (i+1);
 				  if (i < inArr.length + paramArr.length - 1)
						inString += ",";
					if (i === inArr.length + paramArr.length - 1)
						inString += ")";
			}
			console.log(inString);
			paramArr = paramArr.concat(inArr);
			qryStr += " and u.department IN " + inString;
	};

	qryStr = qryStr + order_by;
	console.log(qryStr);
	console.log(paramArr);
	const indSumm = await pool.query( qryStr,paramArr);

	res.json(indSumm.rows);
	}
	catch(err){
		console.error(err.message);
	}

});

//KR DETAILED Report
app.get('/krdetailed/:tenant_id/:locationid/:deptid/:userid/:startdate/:enddate',async(req, res)=>{

	try{
		const tenant_id = req.params.tenant_id;

		const deptid = req.params.deptid;

		console.log(String(deptid));
		var arr = deptid.slice(1, deptid.length);

		arr = arr.slice(0,arr.length - 1);
		console.log(arr);
		console.log(arr.replace(/"/g,''));
		arr = arr.replace(/"/g,'');
		var inArr = arr.split(',');
		console.log(inArr);
		var paramArr = [];
		paramArr.push(tenant_id);
		console.log(paramArr);
		var paramArr = [];
		paramArr.push(tenant_id);
		var order_by =  " ORDER BY u.display_name";
		var qryStr = " select 	u.work_location, u.business_unit, d.name department, u.employee_id EmpCode, u.display_name EmpName, u.designation, lm.employee_id linemanagerecode, " +
 																		 "					lm.display_name line_manager, o.description Obj_Desc, o.objective_type Objective_Type, o.category Category, uo.display_name Obj_Owner,  " +
 																		 " 				  (select sum(cast (ky.obj_progress as real)) obj_progress from key_results ky where ky.objective_id = k.objective_id  group by ky.objective_id) Obj_Progress,  " +
 																		 " 				  k.description KR_Desc,	k.start_date, k.end_date, uk.display_name KR_Owner, um.name KR_UOM, k.boundaries,	k.starting, k.target,	k.activity_description, " +
 																		 " 				  k.kr_status,	k.checkin_status,	k.actual,	k.progress KR_Progress  " +
 																		 " from  " +
 																		 " public.user u, " +
 																		 " public.key_results k,  " +
 																		 " public.objectives o,  " +
 																		 " public.department d,  " +
 																  	 " public.user lm,  " +
 																		 " public.user uo,  " +
 																		 " public.user uk,  " +
																		 " public.unit_of_measurements um" +
 																		 " where  " +
 																		 " u.id = k.user_id and  " +
 																		 " u.tenant_id = k.tenant_id and  " +
 																		 " k.objective_id = o.id and  " +
 																		 " u.department = d.id and  " +
 																		 " lm.id = u.line_manager and  " +
 																		 " uo.id = o.user_id and  " +
 																		 " uk.id = k.user_id and  " +
																		 " um.id = k.uom and " +
 																 		 " u.tenant_id =  $1 ";

		if (req.params.locationid !== 'null')
		{
					qryStr += " and u.work_location = $" + String(paramArr.length + 1);
		 			paramArr.push(req.params.locationid);
		};

	  if (req.params.userid !== 'null')
		{
		 	  qryStr += " and u.id = $" + String(paramArr.length + 1);
		 		paramArr.push(req.params.userid);
		};

		if (req.params.startdate !== 'null')
		{
		   qryStr += " and cast(k.start_date as date) >= $" + String(paramArr.length + 1);
		   paramArr.push(req.params.startdate);
		};

		if (req.params.enddate !== 'null')
		{
				qryStr += " and cast(k.end_date as date) <= $" + String(paramArr.length + 1);
				paramArr.push(req.params.enddate);
		};


		if (req.params.deptid !== 'null')
		{
				var inString = "("
				for (i = paramArr.length; i < inArr.length + paramArr.length; i++){
						inString += "$" + (i+1);
	 				  if (i < inArr.length + paramArr.length - 1)
								inString += ",";
						if (i === inArr.length + paramArr.length - 1)
								inString += ")";
		}
		console.log(inString);
		paramArr = paramArr.concat(inArr);
		qryStr += " and u.department IN " + inString;
	};


		qryStr = qryStr + order_by;
		console.log(qryStr);
		console.log(paramArr.length);
 		const krDtled = await pool.query(qryStr,paramArr);

		res.json(krDtled.rows);
	}
	catch(err){
		console.error(err.message);
	}
});

//Department DETAILED Report
app.get('/deptdetailed/:tenant_id/:locationid/:deptid/:userid/:startdate/:enddate',async(req, res)=>{

	try{
		const tenant_id = req.params.tenant_id;
		const deptid = req.params.deptid;

		console.log(String(deptid));
		var arr = deptid.slice(1, deptid.length);

		arr = arr.slice(0,arr.length - 1);
		console.log(arr);
		console.log(arr.replace(/"/g,''));
		arr = arr.replace(/"/g,'');
		var inArr = arr.split(',');
		console.log(inArr);
		var paramArr = [];
		paramArr.push(tenant_id);
		var order_by =  " ORDER BY u.display_name";
		var qryStr = 										" select u.work_location, (select distinct loc_progress from (select sum(cast(loc.obj_progress as real))/count(distinct loc.userid) loc_progress from " +
																		"	 			 (select u1.id userid, u1.work_location, k1.obj_progress, k1.objective_id  " +
																		"				 from  " +
																		"				 public.user u1, " +
																		"				 key_results k1 " +
																		"				 where  " +
																		"				 k1.user_id = u1.id) loc " +
																		"				 where loc.objective_id = k.objective_id and " +
																		"				 loc.userid = u.id	" +
																		"				 group by loc.work_location) loq) Loc_Progress, u.business_unit, (select distinct bu_progress from (select sum(cast(bui.obj_progress as real))/count(distinct bui.userid) bu_progress from " +
																		"				 (select u2.id userid, u2.business_unit, k2.obj_progress, k2.objective_id  " +
																		"				 from  " +
																		"				 public.user u2, " +
																		"				 key_results k2 " +
																		"				 where  " +
																		"				 k2.user_id = u2.id) bui " +
																		"				 where bui.objective_id = k.objective_id and " +
																		"				 bui.userid = u.id" +
																		"				 group by bui.business_unit) buq) BU_Progress, " +
																		"				 d.name department,(select distinct dept_progress from (select sum(cast(dpt.obj_progress as real))/count(distinct dpt.userid) dept_progress from " +
																		"				 (select u3.id userid, u3.department deptid, k3.obj_progress, k3.objective_id  " +
																		"				 from  " +
																		"				 public.user u3, " +
																		"				 key_results k3 " +
																		"				 where  " +
																		"				 k3.user_id = u3.id) dpt " +
																		"				 where dpt.objective_id = k.objective_id and " +
																		"				 dpt.userid = u.id	" +
																		"				 group by dpt.deptid) dpq) Dept_Progress, " +
																		"				 u.employee_id EmpCode, u.display_name EmpName, lm.employee_id linemanagerecode,  " +
																		"				 lm.display_name line_manager, (select sum( cast(ke.obj_progress as real))/count(distinct ke.objective_id) inv_perf from key_results ke where ke.user_id = k.user_id group by ke.user_id) Indiv_Perf,  " +
																		"				 o.description Obj_Desc, o.objective_type Objective_Type, o.category Category, uo.display_name Obj_Owner,  " +
																		"				 (select sum(cast (ky.obj_progress as real)) obj_progress from key_results ky where ky.objective_id = k.objective_id  group by ky.objective_id) Obj_Progress " +
 																		" from  " +
 																		" public.user u, " +
 																		" public.key_results k,  " +
 																		" public.objectives o,  " +
 																		" public.department d, " +
 																		" public.user lm,  " +
 																		" public.user uo,  " +
 																		" public.user uk  " +
 																		" where  " +
 																		" u.id = k.user_id and  " +
 																		" u.tenant_id = k.tenant_id and  " +
 																		" k.objective_id = o.id and  " +
 																		" u.department = d.id and  " +
 																		" lm.id = u.line_manager and " +
 																		" uo.id = o.user_id and " +
 																		" uk.id = k.user_id and " +
 																		" u.tenant_id =  $1 ";

		if (req.params.locationid !== 'null')
		{
				qryStr += " and u.work_location = $" + String(paramArr.length + 1);
				paramArr.push(req.params.locationid);
		};


		if (req.params.userid !== 'null')
		{
			  qryStr += " and u.id = $" + String(paramArr.length + 1);
		   	paramArr.push(req.params.userid);
		};

		if (req.params.startdate !== 'null')
		{
		   qryStr += " and cast(k.start_date as date) >= $" + String(paramArr.length + 1);
		   paramArr.push(req.params.startdate);
		};

		if (req.params.enddate !== 'null')
		{
			 qryStr += " and cast(k.end_date as date) <= $" + String(paramArr.length + 1);
			 paramArr.push(req.params.enddate);
		};


		if (req.params.deptid !== 'null')
		{
				var inString = "("
				for (i = paramArr.length; i < inArr.length + paramArr.length; i++){
						inString += "$" + (i+1);
					  if (i < inArr.length + paramArr.length - 1)
							 inString += ",";
						if (i === inArr.length + paramArr.length - 1)
							 inString += ")";
		}
		console.log(inString);
		paramArr = paramArr.concat(inArr);
		qryStr += " and u.department IN " + inString;
	};

		qryStr = qryStr + order_by;
		console.log(inString);
		console.log(qryStr);
		console.log(paramArr);
    const deptDtled = await pool.query(qryStr,paramArr);

		res.json(deptDtled.rows);
	}
	catch(err){
		console.error(err.message);
	}
});

//Department Summary Report
app.get('/deptsummary/:tenant_id/:locationid/:deptid/:userid/:startdate/:enddate',async(req, res)=>{

	try{
		const tenant_id = req.params.tenant_id;
		const deptid = req.params.deptid;

		console.log(String(deptid));
		var arr = deptid.slice(1, deptid.length);

		arr = arr.slice(0,arr.length - 1);
		console.log(arr);
		console.log(arr.replace(/"/g,''));
		arr = arr.replace(/"/g,'');
		var inArr = arr.split(',');
		console.log(inArr);
		var paramArr = [];
		paramArr.push(tenant_id);
		var order_by =  " ORDER BY u.display_name";
		var qryStr = 									  " select u.work_location, (select distinct loc_progress from (select sum(cast(loc.obj_progress as real))/count(distinct loc.userid) loc_progress from " +
																		"	 			 (select u1.id userid, u1.work_location, k1.obj_progress, k1.objective_id  " +
																		"				 from  " +
																		"				 public.user u1, " +
																		"				 key_results k1 " +
																		"				 where  " +
																		"				 k1.user_id = u1.id) loc " +
																		"				 where loc.objective_id = k.objective_id and " +
																		"				 loc.userid = u.id	" +
																		"				 group by loc.work_location) loq) Loc_Progress, u.business_unit, (select distinct bu_progress from (select sum(cast(bui.obj_progress as real))/count(distinct bui.userid) bu_progress from " +
																		"				 (select u2.id userid, u2.business_unit, k2.obj_progress, k2.objective_id  " +
																		"				 from  " +
																		"				 public.user u2, " +
																		"				 key_results k2 " +
																		"				 where  " +
																		"				 k2.user_id = u2.id) bui " +
																		"				 where bui.objective_id = k.objective_id and " +
																		"				 bui.userid = u.id" +
																		"				 group by bui.business_unit) buq) BU_Progress, " +
																		"				 d.name department,(select distinct dept_progress from (select sum(cast(dpt.obj_progress as real))/count(distinct dpt.userid) dept_progress from " +
																		"				 (select u3.id userid, u3.department deptid, k3.obj_progress, k3.objective_id  " +
																		"				 from  " +
																		"				 public.user u3, " +
																		"				 key_results k3 " +
																		"				 where  " +
																		"				 k3.user_id = u3.id) dpt " +
																		"				 where dpt.objective_id = k.objective_id and " +
																		"				 dpt.userid = u.id	" +
																		"				 group by dpt.deptid) dpq) Dept_Progress " +
 																		" from  " +
 																		" public.user u, " +
 																		" public.key_results k,  " +
 																		" public.objectives o,  " +
 																		" public.department d " +
 																		" where  " +
 																		" u.id = k.user_id and  " +
 																		" u.tenant_id = k.tenant_id and  " +
 																		" k.objective_id = o.id and  " +
 																		" u.department = d.id and  " +
 																		" u.tenant_id =  $1 ";


		if (req.params.locationid !== 'null')
		{
				qryStr += " and u.work_location = $" + String(paramArr.length + 1);
				paramArr.push(req.params.locationid);
		};

		if (req.params.userid !== 'null')
		{
		   qryStr += " and u.id = $" + String(paramArr.length + 1);
			 paramArr.push(req.params.userid);
		};

		if (req.params.startdate !== 'null')
		{
		   qryStr += " and cast(k.start_date as date) >= $" + String(paramArr.length + 1);
		   paramArr.push(req.params.startdate);
		};

		if (req.params.enddate !== 'null')
		{
		   qryStr += " and cast(k.end_date as date) <= $" + String(paramArr.length + 1);
			 paramArr.push(req.params.enddate);
		};


		if (req.params.deptid !== 'null')
		{
				var inString = "("
				for (i = paramArr.length; i < inArr.length + paramArr.length; i++){
						inString += "$" + (i+1);
					  if (i < inArr.length + paramArr.length - 1)
							 inString += ",";
						if (i === inArr.length + paramArr.length - 1)
							 inString += ")";
		}
		console.log(inString);
		paramArr = paramArr.concat(inArr);
		qryStr += " and u.department IN " + inString;
};

		qryStr = qryStr + order_by;
		console.log(inString);
		console.log(qryStr);
		console.log(paramArr);

    const deptSumm = await pool.query(qryStr,paramArr);

		res.json(deptSumm.rows);
	}
	catch(err){
		console.error(err.message);
	}
});

//Goals DETAILED Report
app.get('/goalsdetailed/:tenant_id/:locationid/:deptid/:userid/:startdate/:enddate',async(req, res)=>{

	try{
		const tenant_id = req.params.tenant_id;
		const deptid = req.params.deptid;

		console.log(String(deptid));
		var arr = deptid.slice(1, deptid.length);

		arr = arr.slice(0,arr.length - 1);
		console.log(arr);
		console.log(arr.replace(/"/g,''));
		arr = arr.replace(/"/g,'');
		var inArr = arr.split(',');
		console.log(inArr);

		var qryStr =  " select (select sum(((cast(g1.q1 as real) + cast(g1.q2 as real) + cast(g1.q3 as real) + cast(g1.q4 as real))/4)*cast(g1.weightage as real)/100) from goals g1 where g1.tenant_id = g.tenant_id group by g1.tenant_id ) overall_goal_progress, g.description goal_description, g.weightage goal_weightage, (cast(g.q1 as real) + cast(g.q2 as real) + cast(g.q3 as real) + cast(g.q4 as real))/4 goal_progress, " +
									"				 o.description obj_description, o.category, u.display_name Obj_Owner, " +
 									" 			(select sum(cast (ky.obj_progress as real)) obj_progress from key_results ky where ky.objective_id = o.id  group by ky.objective_id) Obj_Progress  " +
 									" from  " +
 									" objectives o, " +
 									" goals g , " +
 									" public.user u, " +
									" key_results k" +
 									" where g.id = o.goal_id and " +
 									" o.user_id = u.id and " +
									" k.objective_id = o.id and " +
 									" o.tenant_id = $1  "
    var group_by = " order by o.goal_id ";

		var paramArr = [];
		paramArr.push(tenant_id);


		if (req.params.locationid !== 'null')
		{
				qryStr += " and u.work_location = $" + String(paramArr.length + 1);
				paramArr.push(req.params.locationid);
		};

		if (req.params.userid !== 'null')
		{
		   qryStr += " and u.id = $" + String(paramArr.length + 1);
			 paramArr.push(req.params.userid);
		};

		if (req.params.startdate !== 'null')
		{
		   qryStr += " and cast(k.start_date as date) >= $" + String(paramArr.length + 1);
		   paramArr.push(req.params.startdate);
		};

		if (req.params.enddate !== 'null')
		{
		   qryStr += " and cast(k.end_date as date) <= $" + String(paramArr.length + 1);
			 paramArr.push(req.params.enddate);
		};

		if (req.params.deptid !== 'null')
		{
				var inString = "("
				for (i = paramArr.length; i < inArr.length + paramArr.length; i++){
						inString += "$" + (i+1);
					  if (i < inArr.length + paramArr.length - 1)
							 inString += ",";
						if (i === inArr.length + paramArr.length - 1)
							 inString += ")";
		}
		console.log(inString);
		paramArr = paramArr.concat(inArr);
		qryStr += " and u.department IN " + inString;
};

		//qryStr = qryStr + order_by;
		console.log(inString);
		console.log(qryStr);
		console.log(paramArr);
		const goalsDtled = await pool.query(qryStr, paramArr);

		res.json(goalsDtled.rows);
	}
	catch(err){
		console.error(err.message);
	}
});

//Goals Summary Report
app.get('/goalsummary/:tenant_id/:locationid/:deptid/:userid/:startdate/:enddate',async(req, res)=>{

	try{
		const tenant_id = req.params.tenant_id;
		const deptid = req.params.deptid;

		console.log(String(deptid));
		var arr = deptid.slice(1, deptid.length);

		arr = arr.slice(0,arr.length - 1);
		console.log(arr);
		console.log(arr.replace(/"/g,''));
		arr = arr.replace(/"/g,'');
		var inArr = arr.split(',');
		console.log(inArr);

		var qryStr = 											 " select (select sum(((cast(g1.q1 as real) + cast(g1.q2 as real) + cast(g1.q3 as real) + cast(g1.q4 as real))/4)*cast(g1.weightage as real)/100) from goals g1 where g1.tenant_id = g.tenant_id group by g1.tenant_id ) overall_goal_progress, g.description, o.goal_weightage, " +
																			 "	 		  (cast(g.q1 as real) + cast(g.q2 as real) + cast(g.q3 as real) + cast(g.q4 as real))/4 goal_progress " +
 																	 	   " from  " +
 																	     " public.objectives o, " +
																			 " public.goals g,  " +
																			 " public.user u, " +
																			 " public.key_results k " +
 																	     " where  " +
																			 " g.id = o.goal_id and " +
																			 " o.user_id = u.id and " +
																			 " o.id = k.objective_id and " +
 																	     " o.tenant_id = $1 ";

		var order_by = " order by o.description ";
		var paramArr = [];
		paramArr.push(tenant_id);

				if (req.params.locationid !== 'null')
				{
						qryStr += " and u.work_location = $" + String(paramArr.length + 1);
						paramArr.push(req.params.locationid);
				};

				if (req.params.userid !== 'null')
				{
				   qryStr += " and u.id = $" + String(paramArr.length + 1);
					 paramArr.push(req.params.userid);
				};

				if (req.params.startdate !== 'null')
				{
				   qryStr += " and cast(k.start_date as date) >= $" + String(paramArr.length + 1);
				   paramArr.push(req.params.startdate);
				};

				if (req.params.enddate !== 'null')
				{
				   qryStr += " and cast(k.end_date as date) <= $" + String(paramArr.length + 1);
					 paramArr.push(req.params.enddate);
				};

			 if (req.params.deptid !== 'null')
			 {
						var inString = "("
						for (i = paramArr.length; i < inArr.length + paramArr.length; i++){
								inString += "$" + (i+1);
					  if (i < inArr.length + paramArr.length - 1)
							 inString += ",";
			 		  if (i === inArr.length + paramArr.length - 1)
							 inString += ")";
				}
				console.log(inString);
				paramArr = paramArr.concat(inArr);
				qryStr += " and u.department IN " + inString;
	     };

						//qryStr = qryStr + order_by;
						console.log(inString);
						console.log(qryStr);
						console.log(paramArr);

    const goalsSumm = await pool.query(qryStr,paramArr);

		res.json(goalsSumm.rows);
	}
	catch(err){
		console.error(err.message);
	}
});

/*
app.get('/dummy/:arr', async(req, res)=>{
	try{

    var arr = req.params.arr.slice(1, req.params.arr.length);
		arr = arr.slice(0, arr.length - 1);
		arr = String(arr);
		var inArr = arr.split(',');

		var inString = "("
		for (i = 0; i < inArr.length; i++){
			inString += "$" + (i+1);
			if (i < inArr.length - 1)
			inString += ",";
			if (i === inArr.length - 1)
			inString += ")";
		}
		console.log(inString);
		console.log(inArr);

//		var arr = [753cfa86-20d4-4d47-a899-107344a0aa59,4e633206-8bfa-4a64-b270-20cd0a13cb2e,8b3b8218-6d27-407d-9c48-5f5442f16aeb];
		const goalsSumm = await pool.query(" select count(o.*) " +
																			 " from  " +
																			 " public.user o " +
																			 " where o.work_location IN " + inString, inArr);

		res.json(goalsSumm.rows);
	}
	catch(err){
				console.error(err.message);
	}


});
*/

app.listen(PORT, ()=>{
	console.log("Server listening at Port " + PORT);
});
